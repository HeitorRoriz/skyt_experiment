def pluck(arr):
    smallest_even = float('inf')
    index = -1
    
    for i, value in enumerate(arr):
        if value % 2 == 0 and value < smallest_even:
            smallest_even = value
            index = i
            
    if index == -1:
        return []
    
    return [smallest_even, index]
